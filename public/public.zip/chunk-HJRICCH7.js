import{a}from"./chunk-E7ZOKENL.js";import"./chunk-JHI3MBHO.js";export{a as startFocusVisible};
